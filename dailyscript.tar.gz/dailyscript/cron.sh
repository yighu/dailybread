
cd /home/tomcat/affirmations; /home/tomcat/.sdkman/candidates/groovy/current/bin/groovy MailUtil.groovy>/tmp/t.txt 2>&1
cd /home/tomcat/dailyscript; /home/tomcat/.sdkman/candidates/groovy/current/bin/groovy MailUtilPray.groovy>/tmp/td.txt 2>&1
cd /home/tomcat/dailyscript; /home/tomcat/.sdkman/candidates/groovy/current/bin/groovy MailUtilPrayHebrew.groovy>/tmp/td.txt 2>&1
cd /home/tomcat/dailyscript; /home/tomcat/.sdkman/candidates/groovy/current/bin/groovy TwitterUtil.groovy>/tmp/t.txt 2>&1
cd /home/tomcat/dailyscript; /home/tomcat/.sdkman/candidates/groovy/current/bin/groovy TwitterMembible.groovy>/tmp/t.txt 2>&1
