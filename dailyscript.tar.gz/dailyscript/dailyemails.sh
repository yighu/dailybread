#!/bin/sh
dt=`date '+%m-%d-%y'`
#mail -s "One Year Through Bible (big5) ${dt}"  one-year-through-bible-hb5@googlegroups.com </tmp/today.b5
#mail -s "One Year Through Bible (big5) ${dt}"  one-year-through-bible-nb5@googlegroups.com</tmp/today.nb
mail -s "One Year Through Bible (gb2312) ${dt}"  one-year-through-bible-ngb@googlegroups.com </tmp/today.ng
mail -s "One Year Through Bible (kjv) ${dt}"  one-year-through-bible-kjv@googlegroups.com </tmp/today.kj
mail -s "One Year Through Bible (gb2312) ${dt}"  one-year-through-bible-hgb@googlegroups.com </tmp/today.gb
mail -s "One Year Through Bible (bbe) ${dt}"  one-year-through-bible-bbe@googlegroups.com </tmp/today.be
#mail -s "Streams In the Desert (big5) ${dt}"  streams-in-the-desert-b5@googlegroups.com </var/www/cgi-user/streams/streams_b5.tmp
mail -s "Streams In the Desert (gb2312) ${dt}"  streams-in-the-desert-gb@googlegroups.com </var/www/cgi-user/streams/streams_gb.tmp
