//Prayer scripture
def prayerindex(){
def file=new File("prayerindex.txt")
if(!file.isFile())file.write("0");
def index=file?.text
if(!index){
	index="1"
}
int i=index.toInteger()
if(i>92)i=0
i++
file.write(""+i);
i
}

def prayer(){
def index=prayerindex()
file="/Users/yiguanghu/ccim/prayerministry/daily/tmp/day${index}.htm"
content=file2string(file ,"UTF8")
//to="streams-in-the-desert-gb@googlegroups.com"
def subject="Pray the Scripture"
def from="mailman@ccim.org"
to="yighu@yahoo.com"
sendMail(from,to, subject, content,"UTF8")
}
