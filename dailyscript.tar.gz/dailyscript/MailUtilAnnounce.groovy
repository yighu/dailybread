import org.crosswire.common.xml.*
import java.util.Date;
import java.io.*;
import java.util.*;
import javax.mail.*;
import javax.activation.*;
import javax.mail.internet.*;
import org.crosswire.jsword.book.*
import java.net.MalformedURLException;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import com.google.gson.*;
import org.crosswire.jsword.book.sword.SwordBookPath
import org.crosswire.jsword.index.IndexManagerFactory
import org.crosswire.jsword.passage.Key
import org.crosswire.jsword.passage.NoSuchKeyException
import org.crosswire.jsword.passage.Passage
import org.crosswire.common.util.Translations;
import org.crosswire.bibledesktop.passage.KeyTreeModel
import org.crosswire.jsword.util.ConverterFactory
import org.crosswire.jsword.versification.BibleInfo
import org.crosswire.jsword.bridge.BookInstaller
import org.xml.sax.ContentHandler
import org.xml.sax.SAXException
import grails.converters.*
import org.crosswire.common.util.NetUtil;
import org.crosswire.common.util.ResourceUtil;
import java.text.SimpleDateFormat;
import org.crosswire.jsword.book.Defaults;
import org.crosswire.bibledesktop.desktop.XSLTProperty
import org.crosswire.jsword.versification.BibleNames

   final String BIBLE_PROTOCOL = "bible";                                     //$NON-NLS-1$
   final String DICTIONARY_PROTOCOL = "dict";                                      //$NON-NLS-1$
   final String GREEK_DEF_PROTOCOL = "gdef";                                      //$NON-NLS-1$
   final String HEBREW_DEF_PROTOCOL = "hdef";                                      //$NON-NLS-1$
   final String GREEK_MORPH_PROTOCOL = "gmorph";                                    //$NON-NLS-1$
   final String HEBREW_MORPH_PROTOCOL = "hmorph";                                    //$NON-NLS-1$
   final String COMMENTARY_PROTOCOL = "comment";                                   //$NON-NLS-1$
   final String STRONGS_NUMBERS = "Strongs"; //$NON-NLS-1$
binding['jswordService']=new JswordService()
  binding['xslurl'] = ResourceUtil.getResource("iBD.xsl");
  def  final DELIM = ";"
  def getSchedule() {
  def dailyschedule = new HashMap()
    if (dailyschedule.isEmpty()) {
  def scheduletxt = ResourceUtil.getResource("daily.txt");
      scheduletxt.eachLine {line ->
        if (line.trim().length() > 1) {
          def key = line.substring(0, 4)
          def value = line.substring(5).trim().replaceAll(' ', ",")

          dailyschedule.put(key, value)
        }
      }
    }
    dailyschedule
  }

  String today() {
    def dt = new Date();
    java.text.DateFormat dateFormat = new SimpleDateFormat("MMdd")
    dateFormat.format(dt)
  }

  def dailytxt(String book) {
    def scheules = getSchedule()
    def td = today()
    readStyledText(book, scheules.get(td), 0, 500)
  }


  public String readStyledText(String mainbook, String reference, int start, int maxKeyCount) throws NoSuchKeyException, BookException, SAXException {
    Book book = jswordService.getBook(mainbook);
    SAXEventProvider osissep = jswordService.getOSISProvider(mainbook, reference, start, maxKeyCount);
    if (osissep == null) {
      return ""; //$NON-NLS-1$
    }

    TransformingSAXEventProvider htmlsep = new TransformingSAXEventProvider(NetUtil.toURI(xslurl), osissep); //Customize xslt

    htmlsep.setParameter("VLine", true)
    htmlsep.setParameter("Strongs", "false")
    htmlsep.setParameter("Morph", "false")
    BookMetaData bmd = book.getBookMetaData();
    boolean direction = bmd.isLeftToRight();
    htmlsep.setParameter("direction", direction ? "ltr" : "rtl"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    return XMLUtil.writeToString(htmlsep);
  }

  String day() {
    def dt = new Date();
    java.text.DateFormat dateFormat = new SimpleDateFormat("MM.dd")
    dateFormat.format(dt)
  }


  def public  file2string(String inputfile,String encode){
	String tmline="",line="";

      		FileInputStream fis =new FileInputStream(inputfile);
      		InputStreamReader isr = new InputStreamReader(fis, encode);
      		BufferedReader reader = new BufferedReader(isr);
      while ((tmline = reader.readLine()) != null) {
		line+="<br>\n"+tmline.trim();	
	   }
	line
  }
  def getMailprops(){
     Properties props = new Properties();
     //props.put("mail.host", "rock.ccim.org");
     props.put("mail.host", "localhost.localdomain");
	props.put("mail.smtp.", "true");
	props.put("mail.smtp.port", "25"); 
	props		
	}
  def public  sendMail(from, to, subject, content,encoding)
  {
	Properties props=getMailprops()
     Session session = Session.getDefaultInstance(props, null);
     Message msg = new MimeMessage(session);
     msg.setFrom(new InternetAddress( from ));
     InternetAddress[] addressTo = new InternetAddress[1];
     addressTo[0] = new InternetAddress( to );
     msg.setRecipients(Message.RecipientType.TO, addressTo);
     msg.setHeader("Content-Encoding",encoding);
     msg.setSubject(subject);
     BodyPart messagebody=new MimeBodyPart();
	
     messagebody.setContent(content, "text/html;charset=utf-8");
     Multipart multipart=new MimeMultipart();
	multipart.addBodyPart(messagebody);
	msg.setContent(multipart);
     try
     {
        Transport.send(msg);
     }
     catch (e)
     {
         e.printStackTrace()
     }
  }
  def public  sendBig5Mail(from, to, subject, content)
  {
     // init sesssion
	Properties props=getMailprops()
     Session session = Session.getDefaultInstance(props, null);

     // create a message
     Message msg = new MimeMessage(session);

     // set addresses
     msg.setFrom(new InternetAddress( from ));

     InternetAddress[] addressTo = new InternetAddress[1];
     addressTo[0] = new InternetAddress( to );
     msg.setRecipients(Message.RecipientType.TO, addressTo);
     msg.setContentLanguage(("big5"));
     msg.setHeader("Content-Encoding","big5");
     msg.setSubject(subject);
     msg.setContent(content, "text/plain");

     try
     {
        Transport.send(msg);
     }
     catch (e)
     {
         e.printStackTrace()
     }
  }
  def public  sendMail(from, to, subject, content)
  {
	Properties props=getMailprops()

     Session session = Session.getDefaultInstance(props, null);

     // create a message
     Message msg = new MimeMessage(session);

     // set addresses
     msg.setFrom(new InternetAddress( from ));

     InternetAddress[] addressTo = new InternetAddress[1];
     addressTo[0] = new InternetAddress( to );
     msg.setRecipients(Message.RecipientType.TO, addressTo);

     // set the subject and content
     msg.setSubject(subject);
     msg.setContent(content, "text/plain");

     try
     {
        Transport.send(msg);
        //log.info("mail sent..")
     }
     catch (e)
     {
         e.printStackTrace()
         //log.warn("failed to send error mail: " + e)
     }
  }
  def public  sendMailwAttachment(from, to, subject, content,attachedfile)
  {
	Properties props=getMailprops()
     Session session = Session.getDefaultInstance(props, null);

     // create a message
     Message msg = new MimeMessage(session);

     // set addresses
     msg.setFrom(new InternetAddress( from ));

     InternetAddress[] addressTo = new InternetAddress[1];
     addressTo[0] = new InternetAddress( to );
     msg.setRecipients(Message.RecipientType.TO, addressTo);

     // set the subject and content
     msg.setSubject(subject);

// Create the message part
       BodyPart messageBodyPart = new MimeBodyPart();

     messageBodyPart.setContent(content, "text/html;charset=utf-8");
// Fill the message
       messageBodyPart.setText(content);

       Multipart multipart = new MimeMultipart();
       multipart.addBodyPart(messageBodyPart);

// Part two is attachment
       messageBodyPart = new MimeBodyPart();
       String filename = attachedfile;
       DataSource source = new FileDataSource(filename);
       messageBodyPart.setDataHandler(new DataHandler(source));
       messageBodyPart.setFileName(filename);
       multipart.addBodyPart(messageBodyPart);

 msg.setContent(multipart);
     try
     {
        Transport.send(msg);
        //log.info("mail sent..")
     }
     catch (e)
     {
         e.printStackTrace()
         //log.warn("failed to send error mail: " + e)
     }
  }

def public  sendMailToMultiwAttach(from, recipients, subject, content, attachedfile) {
  // init sesssion
	Properties props=getMailprops()
  Session session = Session.getDefaultInstance(props, null);

  // create a message
  Message msg = new MimeMessage(session);

  // set addresses From
  msg.setFrom(new InternetAddress( from ));

  // set recipients
  InternetAddress[] addressTo = new InternetAddress[recipients.length];
  int count =0;
  recipients.each{
   addressTo[count++] = new InternetAddress( it );
  }
  msg.setRecipients(Message.RecipientType.TO, addressTo);

  // set the subject and content
  msg.setSubject(subject);

  // Create the message part
  BodyPart messageBodyPart = new MimeBodyPart();

  // Fill the message
  messageBodyPart.setText(content);

  Multipart multipart = new MimeMultipart();
  multipart.addBodyPart(messageBodyPart);

  // Part two is attachment
  messageBodyPart = new MimeBodyPart();
  String filename = attachedfile;
  DataSource source = new FileDataSource(filename);
  messageBodyPart.setDataHandler(new DataHandler(source));
  messageBodyPart.setFileName(filename);
  multipart.addBodyPart(messageBodyPart);

  msg.setContent(multipart);

  // send mail
  try{
     Transport.send(msg);
  } catch (e) {
      e.printStackTrace()
  }
}

  def public  sendMultiMail(from, to, subject, content)
  {
     // init sesssion
     Properties props = new Properties();
     props.put("mail.host", "rock.ccim.org");

     Session session = Session.getDefaultInstance(props, null);

     // create a message
     Message msg = new MimeMessage(session);

     // set addresses
     msg.setFrom(new InternetAddress( from ));

     InternetAddress[] addressTo = new InternetAddress[to.length];
     int count =0;
     to.each{
      addressTo[count++] = new InternetAddress( it );
     }
     msg.setRecipients(Message.RecipientType.TO, addressTo);
     // set the subject and content
     msg.setSubject(subject);
     msg.setContent(content, "text/plain");

     try
     {
        Transport.send(msg);
        //log.info("mail sent..")
     }
     catch (e)
     {
         e.printStackTrace()
         //log.warn("failed to send error mail: " + e)
     }
  }


//Prayer scripture
def prayerindex(){
def file=new File("../prayer/prayerindex.txt")
if(!file.isFile())file.write("0");
def index=file?.text
if(!index){
	index="1"
}
int i=index.toInteger()
if(i>92)i=0
i++
file.write(""+i);
i
}

def prayer(){
def index=prayerindex()
println index
//file="/Users//ccim/prayerministry/daily/tmp/day${index}.htm"
file="prayeremail.txt"
//content=file2string(file ,"UTF8")
content=new File(file).text
def attachedfile="../prayer/day${index}.pdf"
def to="prayscripture@googlegroups.com"
//to="@gmail.com"
        Date dateNow = new Date ();
       SimpleDateFormat dateformatMMDDYYYY = new SimpleDateFormat("MM-dd-yyyy");
 
def subject=" Pray the Scripture "+dateformatMMDDYYYY.format( dateNow ) 
def from="mailman@ccim.org"
from="prayscripture@gmail.com"
sendMailwAttachment(from, to, subject, content,attachedfile)
}

def generateAllTxt(){
def file = new File('oneandhalfyearplan.txt')
file.eachLine{ line, index->
    def txt=readStyledText("KJV", line, 0, 500)
	new File("tmp/day${index}.txt").write(line+"\n"+txt)
}
}


def selectEvoke(){

def txt=["psa 16:8","psa 27:4", "psa 27:9-10","psa 40:16-17","psa 63:1-3","psa 84:5-7","psa 103:1-2", "psa 139:7-10","isa 57:15","matt 11:28-30","john 4:23", "eph 1:17-19","eph 3:16-20"]
def max= txt.size()
def rand = new Random()  
def idx=rand.nextInt(max)
def chosen="gen 1"
txt.eachWithIndex{v,id->
if (id==idx)chosen=v
}
chosen
}
 def genDaily(results,evoke){
"""
	<h1>Approaching God亲近神</h1>      
<p>	Think of the privilege of Prayer. Realize God is Present. Ask Him to help you pray.</p>
<p>思想我们祷告的权柄。意识到神就在这儿。请他帮助祷告。</p>
      ${evoke}
	<h1>Meditate His Word诵读默思他的话语</h1>      
      ${results}
<br/>
<p>Discern one or two truths you learn from these passages. Choose the one that most impresses you and write it in a sentence. </p><p>Now ask: How does this truth help me praise God? How does it show me a sin to confess? How does it show me something to ask God for? </p>	
<p>从这段经文中找出一两个真理。选择其中一个并写成句。问这些问题：这个真理如何帮助我赞美神？他如何揭示我当承认的罪？他如何显明我哪些方面需要求神帮助。</p>
<br/>
	<h1>Word Prayer话语祷告</h1>      
	<p>Turn the answers to the three questions into prayer-adoration, petition, and supplication</p>
	<p>将对这三个问题的答案转为祷告：颂赞，请求和祷告</p>
	<h1>Free Prayer自由祷告</h1>      
<p> Pray about whatever needs are on your heart. Spend time thanking God for the ways you see him working in your life and caring for you.  </p>
<p>将内心的负担向神祷告。感谢神在你生命中的工作和他对你的关爱。 </p>
<h1>Contemplation沉思</h1>
<p> Take a moment to thank and admire God for what he has showed you today. End with a note of praise. </p>
<p>感谢神的带领并赞美他。 </p>
"""
  }
  def getThreeyearSchedule() {
List threeschedule=new ArrayList()
  final threeplan=new File("threeyeardaily.txt")
	  threeplan.eachLine {line ->
    		threeschedule.add(line) }

    		threeschedule
  }
  def getthreeyearschedule(){
		def idx=index4today(2011,12,31,1095)
		def vs="gen 1"
  		vs=getThreeyearSchedule().get(idx) 
		vs
	}
	def index4today(year,mon,day,leng){
	  GregorianCalendar start= new GregorianCalendar(year,mon,day);
  GregorianCalendar end= new GregorianCalendar();
  long ms1 = start.getTime().getTime();
  long ms2 = end.getTime().getTime();
  long difMs = ms2-ms1;
  long msPerDay = 1000*60*60*24;
  ((int)(difMs / msPerDay)).mod(leng);
	}
def todaystring(){
        Date dateNow = new Date ();
       SimpleDateFormat dateformatMMDDYYYY = new SimpleDateFormat("MM-dd-yyyy");
	dateformatMMDDYYYY.format( dateNow ) 
}
subject="邀请你参与每年读经一遍计划及每周的线上集会"
content='''
主内的弟兄姊妹朋友们：

本周日美国东部时间早上是一年通读圣经的第一次线上聚会。

本周读经内容包括约书亚记，约伯记，使徒行传。约书亚记部分记载约书亚带领以色列进入迦南的故事。这是一段很有争议的经文。也可能让很多人困惑。在这一断经文中，巨人，灭绝这样的词汇集中频繁出现在这些经文中。这些巨人是谁？为什么让以色列那么害怕？神不是爱吗？为什么要对这些人赶尽杀绝？这些都是好问题。由于这段经文特别让人困惑。我会专门用这周聚会的部分时间讨论这段记载。理解这段经文会让我们更好地阅读整本圣经，明白神的永恒计划。他的慈爱直到永远！

主日聚会的计划，安排，细节都会在这个文件中。请保存下面这个连接。


https://docs.google.com/document/d/180s8DDF4W_hsSSzaJWnIqUjLmjmfQlhxqJ1vxhJzrX4/edit?usp=sharing

需要鼓舞的欢迎观看这个正道：
https://youtu.be/TKW79OUnjm8?si=cBXO5JT0f3QHPpgx

'''
subject="请帮忙维护圣经邮件服务！"
content='''
弟兄姊妹朋友们：

我是每日读经邮件的发起人和管理者。这个服务已经延续了20来年。我常要花很多时间来处理发送失败的问题。你如果收到的邮件不是午夜发送的，那都是我重新发送的结果。

邮件发送失败的主要原因是一些用户将这个服务发送的邮件当成spam对待。google 发现邮件是spam后就开始filter或者block。这样我就不得不反复发送直到成功。这浪费了我很多时间。

因此我在此单独发这个邮件：请求你不要将邮件当spam。

你在这个邮件上是因为你自己加入了这个服务。你如果不再需要这个服务，请麻烦你自己退出这个服务，你如果不知道如何退出，请发邮件给我，我可以将你去除。

我建立这个服务，完全是为了帮助大家熟悉圣经，没有任何别的企图。我很高兴为大家服务。这是完全自由的，免费的。
但是我有一份全职的工作要作，有家庭，有教会的责任。同大家一样，时间很宝贵。

谢谢你留意，愿神赐福你！
'''
from="chesedemity@gmail.com"
tos=["GreekNewTestament2yearsreadplan@googlegroups.com",
"one-year-through-bible-bbe@googlegroups.com",
"one-year-through-bible-hb5@googlegroups.com",
"one-year-through-bible-hgb@googlegroups.com",
"one-year-through-bible-kjv@googlegroups.com",
"one-year-through-bible-nb5@googlegroups.com",
"one-year-through-bible-ngb@googlegroups.com",
"prayscripture@googlegroups.com",
"oneyearthroughntgreek@googlegroups.com",
"readthroughhebrewbiblein3years@googlegroups.com",
"streams-in-the-desert-b5@googlegroups.com",
"streams-in-the-desert-gb@googlegroups.com",
"three-year-pray-through-bible-traditional-chinese@googlegroups.com",
"three-years-pray-through-bible-simplified-chinese@googlegroups.com",
"three-years-through-bible-kjv@googlegroups.com"]
for(String to in tos){
System.out.println("send to:"+to)
sendMail(from,to, subject, content,"UTF8")
sleep(3000)
}
