import twitter4j.TwitterException;
import twitter4j.internal.http.HttpResponse;
import javax.crypto.spec.SecretKeySpec;
import twitter4j.http.*;
import twitter4j.*;
//Gsword twitter info
if(false){
	AccessToken atk=new AccessToken("33532940-nGxF0r1V30V017XQ2ML19MDkIcLP3RI6xT2oVbePL","d0uSDWzMgkx6GYU5I1zCfJvhxObBjSdl4CS3OMfP4E");
        Twitter	twitter=new TwitterFactory().getOAuthAuthorizedInstance("S59vTBukcU1K5LhsCJe0LQ", "FHEqcCcw6S1uXwO0cqv53BL3Nil5QAbVt6Uol50uuQA",atk);
    Status status = twitter.updateStatus("This is the day!");
    System.out.println("Successfully updated the status to [" + status.getText() + "].");
}
if(true){
	AccessToken atk=new AccessToken("80463491-ZmWMuVYjKU5CLSYZOqNagiSnchyb8J9u8CFoCYgt6","osgqhBhpOpynF5HF8krrxy6mm5VJUaU0gpy2FQqFnes")
        Twitter	twitter=new TwitterFactory().getOAuthAuthorizedInstance("qoWOoasLCzcmN3p8XsWQ", "1uHHYgsX1qGMJaoNHkVMgbXwjqi7acjnqtwSIoW4xFk",atk);

    Status status = twitter.updateStatus("This is the day!");
    System.out.println("Successfully updated the status to [" + status.getText() + "].");
}
/*
Consumer key
S59vTBukcU1K5LhsCJe0LQ
Consumer secret
FHEqcCcw6S1uXwO0cqv53BL3Nil5QAbVt6Uol50uuQA
Request token URL
https://twitter.com/oauth/request_token
Access token URL
https://twitter.com/oauth/access_token
Authorize URL
https://twitter.com/oauth/authorize
*/
