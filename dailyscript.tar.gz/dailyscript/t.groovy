import java.util.Date;
import java.text.SimpleDateFormat;
 
        Date dateNow = new Date ();
        SimpleDateFormat dateformatMMDDYYYY = new SimpleDateFormat("MM-dd-yyyy");
        dateformatMMDDYYYY.format( dateNow ) 
 
