import java.util.Date;
import java.io.*;
import java.util.*;
import javax.mail.*;
import javax.activation.*;
import javax.mail.internet.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import com.google.gson.*;
import org.xml.sax.ContentHandler
import org.xml.sax.SAXException
import grails.converters.*
import java.text.SimpleDateFormat;


  def getMailprops(){
     Properties props = new Properties();
     //props.put("mail.host", "rock.ccim.org");
     props.put("mail.host", "localhost.localdomain");
	props.put("mail.smtp.", "true");
	props.put("mail.smtp.port", "25"); 
	props		
	}
  def public  sendMail(from, to, subject, content,encoding)
  {
	Properties props=getMailprops()
     Session session = Session.getDefaultInstance(props, null);
     Message msg = new MimeMessage(session);
     msg.setFrom(new InternetAddress( from ));
     InternetAddress[] addressTo = new InternetAddress[1];
     addressTo[0] = new InternetAddress( to );
     msg.setRecipients(Message.RecipientType.TO, addressTo);
     msg.setHeader("Content-Encoding",encoding);
     msg.setSubject(subject);
     BodyPart messagebody=new MimeBodyPart();
	
     messagebody.setContent(content, "text/html;charset=utf-8");
     Multipart multipart=new MimeMultipart();
	multipart.addBodyPart(messagebody);
	msg.setContent(multipart);
     try
     {
        Transport.send(msg);
     }
     catch (e)
     {
         e.printStackTrace()
     }
  }
def testWeb(site){
def url = new URL(site) 
def connection = url.openConnection() 
if(connection.responseCode == 200){
 println "${site} is good" 
}
else{
def subject="Site ${site} is down"
def content="error occurred:${connection.responseCode} ${connection.responseMessage}"
  sendMail("xyz@gmail.com", "xyz@gmail.com", subject, content,"UTF-8")
}
}
["http://www.gsword.org/gbook/vp/1"].each{
testWeb(it)
}
