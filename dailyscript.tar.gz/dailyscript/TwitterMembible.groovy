import twitter4j.http.*;
import twitter4j.*;
import twitter4j.conf.*;
binding['jswordService']=new JswordService()


  def segment(String s,List rst){
          if (s.size()<=140){
            rst.add(s)
          }else{
           rst.add(s.substring(0,140))
           segment(s.substring(140),rst)
          }
          return rst
  }

    def update(Twitter twitter, String data){
           segment(data,new ArrayList()).each{
		println "here:"+it
            twitter.updateStatus(it);
           }
           }

    def twist(String data){
	if (data?.size()>140)data=data.substring(0,140)
	data
	}
    def membible() {
	def conf = new ConfigSlurper().parse(new File('TwitterMembibleConfig.groovy').toURL())
   ConfigurationBuilder cb = new ConfigurationBuilder();
cb.setDebugEnabled(true)
  .setOAuthConsumerKey(conf.consumerkey)
  .setOAuthConsumerSecret(conf.consumerkeysecret)
  .setOAuthAccessToken(conf.accesstoken)
  .setOAuthAccessTokenSecret(conf.accesstokensecret)
TwitterFactory tf = new TwitterFactory(cb.build());
Twitter twitter = tf.getInstance();

      def verse = jswordService.memVerse()
println "verse=:"+verse
      def data = jswordService.getPlainText("KJV", verse)
	println "data="+data
      try {
      update(twitter,verse + " " + data);
      data = jswordService.getPlainText("ChiUn", verse)
      update(twitter,verse + " " + data.replaceAll(" ", ""));
      data = jswordService.getPlainText("LXX", verse)
      update(twitter,verse + " " + data.replaceAll(" ", ""));
      data = jswordService.getPlainText("HebModern", verse)
      update(twitter,verse + " " + data.replaceAll(" ", ""));
        } catch (InterruptedException ex) {
        ex.printStackTrace()
        }
    }

  def timeline=""
  def ACCEPTEDTWITTER = ['RickWarren','MaxLucado', 'johncmaxwell', 'JohnPiper', 'gsword','membible','c3i_Leadership'] as Set

  def getTimeline() {
    if (!timeline) {
      timeline = fetchTimeline()
    }
    timeline
  }

    membible() 
