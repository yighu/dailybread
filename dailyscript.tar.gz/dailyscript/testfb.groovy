import com.restfb.*
import com.restfb.types.*
/***
Toget access token
1. goto https://developers.facebook.com/tools/explorer/?method=GET&path=OneYearThroughBible
2.click get access token
3. specifiy permissions under all three tabs
4. Copy the access token 
API DOC http://restfb.com/javadoc/index.html
***/
ONEYEARBIBLE_ACCESS_TOKEN="BAACEdEose0cBAONECh3umkZBf90Ys37AnPGBr4w3N8LZC1xwVysp1cpIYfkspIQuDsXcOtNxTKxWdbFiEpHxN9ZAEDPzVZAU64rfJl2svc7lFVlMuwBnLxWS76fbiHceeIgGomTSe4kGzPHgkVTAvxmqQnub1uT1ttKboxCP8QcZCjyLpilUAaU8ZCdk9ZAD92EENeFzxOvJgZDZD"
FacebookClient facebookClient = new DefaultFacebookClient( ONEYEARBIBLE_ACCESS_TOKEN)
User user = facebookClient.fetchObject("me", User.class);

println("User name: " + user.getName());
//Retrive page access token
//https://developers.facebook.com/tools/explorer/?method=GET&path=OneYearThroughBible

def accessToken =
  new DefaultFacebookClient().obtainAppAccessToken("504216372958133", "c85ee709989db9f05b04bfbb5738903a")

println("My application access token: " + accessToken.accessToken);

facebookClient = new DefaultFacebookClient(ONEYEARBIBLE_ACCESS_TOKEN)
FacebookType publishMessageResponse1 =
  facebookClient.publish("OneYearThroughBible/feed", FacebookType.class,
    Parameter.with("message", "RestFB test again"));

println("Published message ID: " + publishMessageResponse1.getId());
