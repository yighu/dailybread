#!/bin/sh
#groovy  -cp :../twitter4j-core-2.1.3.jar:../twitter4j-examples-2.1.3.jar:lib/jdom-1.0.jar:lib/junit-3.8.2.jar:lib/rome-0.9.jar TwitterOAuth.groovy
#groovy  -cp :../twitter4j-core-2.1.3.jar:../twitter4j-examples-2.1.3.jar:lib/jdom-1.0.jar:lib/junit-3.8.2.jar:lib/rome-0.9.jar Tt.groovy
groovy  Tt.groovy
