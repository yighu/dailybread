#!/usr/local/bin/perl
# To dynamically choose a different passage to display everyday
# according to the actual date 
# Chinese Christian Internet Mission, all rights reserved
# author: Allan Tze-Ming Ku
# Rev 1.0,  2/27/99
# Rev 1.01, 3/1/99  Added a "+" in spliter "\s" for single-digit dates
# Rev 1.02  3/2/99  Added a <PRE> pair to retain the format of the original text
# Rev 1.03, 3/27/99 Added a counter and the copyright notice
# Rev 1.10, 3/27/99 Added &font=b5 for b5 & gb options
# Rev 1.11, 6/2/99  fixed "June" to "Jun" in $month hash
# Rev 1.12, 7/12/99  fixed "July" to "Jul" in $month hash
# Rev 1.13, 8/9/99  added a mailing functionality
# Rev 1.14, 8/25/99 added charset in mailheader
# Rev 1.5   3/22/00 fixed so the JavaScript TopMenuBar and Fuyin icon works
# Rev 1.51  7/27/00 added versions to "From:" and "Subject:"	
# Rev 2.00, 1/28/01  renamed switch "font" to "encoding", but still backward compatible
# Rev 2.01, 2/08/01 Changed "listening to fuyin.com" icon to a prettier one.


#require "html_header.pl";
#require "/usr/local/etc/httpd/cgi-user/aku/cgi-lib.pl";
#&ReadParse(*FORM);

require "/var/www/cgi-user/streams/subscribe.pl";
use Getopt::Long;
&GetOptions("b5:s","gb:s");

if (defined ($opt_gb)) {	$encoding="gb";
} else {			$encoding="b5";
} #if

#########################
# months translation  ###
#########################
$month{Jan}="jan";
$month{Feb}="feb";
$month{Mar}="mar";
$month{Apr}="apr";
$month{May}="may";
$month{Jun}="june";
$month{Jul}="july";
$month{Aug}="aug";
$month{Sep}="sept";
$month{Oct}="oct";
$month{Nov}="nov";
$month{Dec}="dec";

#########################
## obtain current date ##
#########################
open (DATE, "/bin/date |");
while (<DATE>) {
($junk,$current_month,$current_date,$junk2)=split /\s+/,$_, 4; 
}
close(DATE);

#########################
## displaying        ####
#########################
$file=	"/var/www/html/streams/${encoding}/$month{$current_month}/$month{$current_month}-$current_date.txt";
#$TopMenuBar=	"/export/ccim/www/htdocs/Include/TopMenuBar.html";
$TopMenuBar=	"/export/ccim/www/htdocs/TopMenuBar/include.html";
$pics_dir=	"http://streams.ccim.org/pics";
$banner=	"${pics_dir}/banner.jpg";
$icon=		"${pics_dir}/icon.jpg";
$tmp_file=	"streams_${encoding}.tmp";
$sendmail=	"/usr/lib/sendmail -t";
$charset{gb}=	"gb2312";
$charset{b5}=	"Big5";
$other{gb}=	"streams_b5";
$other{b5}=	"streams_gb";

open (TMP, ">$tmp_file");
print TMP <<ARUBA;
ARUBA

print TMP "<HR>";  ### to retain the format of the original text

print TMP "<HR><P><PRE>";  ### to retain the format of the original text

open (CAT,"$file");
while (<CAT>) {
print TMP ; 
} #while
close (CAT);

print TMP "</PRE>\n";
print TMP "<a href=\"http://groups.google.com/group/one-year-through-bible-bbe/web/one-year-through-bible\">More Instruction</a>";
print TMP "<br><p>";
open (CAT,"/home/mailman/news/news.txt");
while (<CAT>) {
print TMP "<br>";
print TMP ; 
} #while
close (CAT);
