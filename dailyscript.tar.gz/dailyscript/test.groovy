def prayerindex(){
def file=new File("../prayer/prayerindex.txt")
if(!file.isFile())file.write("0");
def index=file?.text
if(!index){
	index="1"
}
int i=index.toInteger()
if(i>92)i=0
i++
file.write(""+i);
i
}

def prayer(){
def index=prayerindex()
println index
}
prayer()
