    		String inputfile=args[0],date=args[3],encode=args[2]; 
    		String tmline = "", line="";
      		FileInputStream fis =new FileInputStream(inputfile);
      		InputStreamReader isr = new InputStreamReader(fis, encode);
      		BufferedReader reader = new BufferedReader(isr);
		def writer=new File("streamss.imp").newWriter("UTF8",true)
      while ((tmline = reader.readLine()) != null) {
		line+="<br>\n"+tmline.trim();	
	   }
		writer.append("\$\$\$"+date+"\n")
		writer.append(line+"\n")
		writer.flush()

