import org.crosswire.common.xml.*
import java.util.Date;
import java.io.*;
import java.util.*;
import javax.mail.*;
import javax.activation.*;
import javax.mail.internet.*;
import org.crosswire.jsword.book.*
import java.net.MalformedURLException;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import com.google.gson.*;
import org.crosswire.jsword.book.sword.SwordBookPath
import org.crosswire.jsword.index.IndexManagerFactory
import org.crosswire.jsword.passage.Key
import org.crosswire.jsword.passage.NoSuchKeyException
import org.crosswire.jsword.passage.Passage
import org.crosswire.common.util.Translations;
import org.crosswire.bibledesktop.passage.KeyTreeModel
import org.crosswire.jsword.util.ConverterFactory
import org.crosswire.jsword.versification.BibleInfo
import org.crosswire.jsword.bridge.BookInstaller
import org.xml.sax.ContentHandler
import org.xml.sax.SAXException
import grails.converters.*
import org.crosswire.common.util.NetUtil;
import org.crosswire.common.util.ResourceUtil;
import java.text.SimpleDateFormat;
import org.crosswire.jsword.book.Defaults;
import org.crosswire.bibledesktop.desktop.XSLTProperty
import org.crosswire.jsword.versification.BibleNames

   final String BIBLE_PROTOCOL = "bible";                                     //$NON-NLS-1$
   final String DICTIONARY_PROTOCOL = "dict";                                      //$NON-NLS-1$
   final String GREEK_DEF_PROTOCOL = "gdef";                                      //$NON-NLS-1$
   final String HEBREW_DEF_PROTOCOL = "hdef";                                      //$NON-NLS-1$
   final String GREEK_MORPH_PROTOCOL = "gmorph";                                    //$NON-NLS-1$
   final String HEBREW_MORPH_PROTOCOL = "hmorph";                                    //$NON-NLS-1$
   final String COMMENTARY_PROTOCOL = "comment";                                   //$NON-NLS-1$
   final String STRONGS_NUMBERS = "Strongs"; //$NON-NLS-1$
binding['jswordService']=new JswordService()
  binding['xslurl'] = ResourceUtil.getResource("iBD.xsl");
  def  final DELIM = ";"
  def getSchedule() {
  def dailyschedule = new HashMap()
    if (dailyschedule.isEmpty()) {
  def scheduletxt = ResourceUtil.getResource("daily.txt");
      scheduletxt.eachLine {line ->
        if (line.trim().length() > 1) {
          def key = line.substring(0, 4)
          def value = line.substring(5).trim().replaceAll(' ', ",")

          dailyschedule.put(key, value)
        }
      }
    }
    dailyschedule
  }

  String today() {
    def dt = new Date();
    java.text.DateFormat dateFormat = new SimpleDateFormat("MMdd")
    dateFormat.format(dt)
  }

  def dailytxt(String book) {
    def scheules = getSchedule()
    def td = today()
    readStyledText(book, scheules.get(td), 0, 500)
  }


  public String readStyledText(String mainbook, String reference, int start, int maxKeyCount) throws NoSuchKeyException, BookException, SAXException {
    Book book = jswordService.getBook(mainbook);
    SAXEventProvider osissep = jswordService.getOSISProvider(mainbook, reference, start, maxKeyCount);
    if (osissep == null) {
      return ""; //$NON-NLS-1$
    }

    TransformingSAXEventProvider htmlsep = new TransformingSAXEventProvider(NetUtil.toURI(xslurl), osissep); //Customize xslt

    htmlsep.setParameter("VLine", true)
    htmlsep.setParameter("Strongs", "false")
    htmlsep.setParameter("Morph", "false")
    BookMetaData bmd = book.getBookMetaData();
    boolean direction = bmd.isLeftToRight();
    htmlsep.setParameter("direction", direction ? "ltr" : "rtl"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    return XMLUtil.writeToString(htmlsep);
  }

  String day() {
    def dt = new Date();
    java.text.DateFormat dateFormat = new SimpleDateFormat("MM.dd")
    dateFormat.format(dt)
  }


  def public  file2string(String inputfile,String encode){
	String tmline="",line="";

      		FileInputStream fis =new FileInputStream(inputfile);
      		InputStreamReader isr = new InputStreamReader(fis, encode);
      		BufferedReader reader = new BufferedReader(isr);
      while ((tmline = reader.readLine()) != null) {
		line+="<br>\n"+tmline.trim();	
	   }
	line
  }
  def getMailprops(){
     Properties props = new Properties();
     //props.put("mail.host", "rock.ccim.org");
     props.put("mail.host", "localhost.localdomain");
	props.put("mail.smtp.", "true");
	props.put("mail.smtp.port", "25"); 
	props		
	}
  def public  sendMail(from, to, subject, content,encoding)
  {
	Properties props=getMailprops()
     Session session = Session.getDefaultInstance(props, null);
     Message msg = new MimeMessage(session);
     msg.setFrom(new InternetAddress( from ));
     InternetAddress[] addressTo = new InternetAddress[1];
     addressTo[0] = new InternetAddress( to );
     msg.setRecipients(Message.RecipientType.TO, addressTo);
     msg.setHeader("Content-Encoding",encoding);
     msg.setSubject(subject);
     BodyPart messagebody=new MimeBodyPart();
	
     messagebody.setContent(content, "text/html;charset=utf-8");
     Multipart multipart=new MimeMultipart();
	multipart.addBodyPart(messagebody);
	msg.setContent(multipart);
     try
     {
        Transport.send(msg);
     }
     catch (e)
     {
         e.printStackTrace()
     }
  }
  def public  sendBig5Mail(from, to, subject, content)
  {
     // init sesssion
	Properties props=getMailprops()
     Session session = Session.getDefaultInstance(props, null);

     // create a message
     Message msg = new MimeMessage(session);

     // set addresses
     msg.setFrom(new InternetAddress( from ));

     InternetAddress[] addressTo = new InternetAddress[1];
     addressTo[0] = new InternetAddress( to );
     msg.setRecipients(Message.RecipientType.TO, addressTo);
     msg.setContentLanguage(("big5"));
     msg.setHeader("Content-Encoding","big5");
     msg.setSubject(subject);
     msg.setContent(content, "text/plain");

     try
     {
        Transport.send(msg);
     }
     catch (e)
     {
         e.printStackTrace()
     }
  }
  def public  sendMail(from, to, subject, content)
  {
	Properties props=getMailprops()

     Session session = Session.getDefaultInstance(props, null);

     // create a message
     Message msg = new MimeMessage(session);

     // set addresses
     msg.setFrom(new InternetAddress( from ));

     InternetAddress[] addressTo = new InternetAddress[1];
     addressTo[0] = new InternetAddress( to );
     msg.setRecipients(Message.RecipientType.TO, addressTo);

     // set the subject and content
     msg.setSubject(subject);
     msg.setContent(content, "text/plain");

     try
     {
        Transport.send(msg);
        //log.info("mail sent..")
     }
     catch (e)
     {
         e.printStackTrace()
         //log.warn("failed to send error mail: " + e)
     }
  }
  def public  sendMailwAttachment(from, to, subject, content,attachedfile)
  {
	Properties props=getMailprops()
     Session session = Session.getDefaultInstance(props, null);

     // create a message
     Message msg = new MimeMessage(session);

     // set addresses
     msg.setFrom(new InternetAddress( from ));

     InternetAddress[] addressTo = new InternetAddress[1];
     addressTo[0] = new InternetAddress( to );
     msg.setRecipients(Message.RecipientType.TO, addressTo);

     // set the subject and content
     msg.setSubject(subject);

// Create the message part
       BodyPart messageBodyPart = new MimeBodyPart();

     messageBodyPart.setContent(content, "text/html;charset=utf-8");
// Fill the message
       messageBodyPart.setText(content);

       Multipart multipart = new MimeMultipart();
       multipart.addBodyPart(messageBodyPart);

// Part two is attachment
       messageBodyPart = new MimeBodyPart();
       String filename = attachedfile;
       DataSource source = new FileDataSource(filename);
       messageBodyPart.setDataHandler(new DataHandler(source));
       messageBodyPart.setFileName(filename);
       multipart.addBodyPart(messageBodyPart);

 msg.setContent(multipart);
     try
     {
        Transport.send(msg);
        //log.info("mail sent..")
     }
     catch (e)
     {
         e.printStackTrace()
         //log.warn("failed to send error mail: " + e)
     }
  }

def public  sendMailToMultiwAttach(from, recipients, subject, content, attachedfile) {
  // init sesssion
	Properties props=getMailprops()
  Session session = Session.getDefaultInstance(props, null);

  // create a message
  Message msg = new MimeMessage(session);

  // set addresses From
  msg.setFrom(new InternetAddress( from ));

  // set recipients
  InternetAddress[] addressTo = new InternetAddress[recipients.length];
  int count =0;
  recipients.each{
   addressTo[count++] = new InternetAddress( it );
  }
  msg.setRecipients(Message.RecipientType.TO, addressTo);

  // set the subject and content
  msg.setSubject(subject);

  // Create the message part
  BodyPart messageBodyPart = new MimeBodyPart();

  // Fill the message
  messageBodyPart.setText(content);

  Multipart multipart = new MimeMultipart();
  multipart.addBodyPart(messageBodyPart);

  // Part two is attachment
  messageBodyPart = new MimeBodyPart();
  String filename = attachedfile;
  DataSource source = new FileDataSource(filename);
  messageBodyPart.setDataHandler(new DataHandler(source));
  messageBodyPart.setFileName(filename);
  multipart.addBodyPart(messageBodyPart);

  msg.setContent(multipart);

  // send mail
  try{
     Transport.send(msg);
  } catch (e) {
      e.printStackTrace()
  }
}

  def public  sendMultiMail(from, to, subject, content)
  {
     // init sesssion
     Properties props = new Properties();
     props.put("mail.host", "rock.ccim.org");

     Session session = Session.getDefaultInstance(props, null);

     // create a message
     Message msg = new MimeMessage(session);

     // set addresses
     msg.setFrom(new InternetAddress( from ));

     InternetAddress[] addressTo = new InternetAddress[to.length];
     int count =0;
     to.each{
      addressTo[count++] = new InternetAddress( it );
     }
     msg.setRecipients(Message.RecipientType.TO, addressTo);
     // set the subject and content
     msg.setSubject(subject);
     msg.setContent(content, "text/plain");

     try
     {
        Transport.send(msg);
        //log.info("mail sent..")
     }
     catch (e)
     {
         e.printStackTrace()
         //log.warn("failed to send error mail: " + e)
     }
  }


//Prayer scripture
def prayerindex(){
def file=new File("../prayer/prayerindex.txt")
if(!file.isFile())file.write("0");
def index=file?.text
if(!index){
	index="1"
}
int i=index.toInteger()
if(i>92)i=0
i++
file.write(""+i);
i
}

def prayer(){
def index=prayerindex()
println index
//file="/Users//ccim/prayerministry/daily/tmp/day${index}.htm"
file="prayeremail.txt"
//content=file2string(file ,"UTF8")
content=new File(file).text
def attachedfile="../prayer/day${index}.pdf"
def to="prayscripture@googlegroups.com"
//to="@gmail.com"
        Date dateNow = new Date ();
       SimpleDateFormat dateformatMMDDYYYY = new SimpleDateFormat("MM-dd-yyyy");
 
def subject=" Pray the Scripture "+dateformatMMDDYYYY.format( dateNow ) 
def from="mailman@ccim.org"
from="prayscripture@gmail.com"
sendMailwAttachment(from, to, subject, content,attachedfile)
}

def generateAllTxt(){
def file = new File('oneandhalfyearplan.txt')
file.eachLine{ line, index->
    def txt=readStyledText("KJV", line, 0, 500)
	new File("tmp/day${index}.txt").write(line+"\n"+txt)
}
}


def selectEvoke(){

def txt=["psa 16:8","psa 27:4", "psa 27:9-10","psa 40:16-17","psa 63:1-3","psa 84:5-7","psa 103:1-2", "psa 139:7-10","isa 57:15","matt 11:28-30","john 4:23", "eph 1:17-19","eph 3:16-20"]
def max= txt.size()
def rand = new Random()  
def idx=rand.nextInt(max)
def chosen="gen 1"
txt.eachWithIndex{v,id->
if (id==idx)chosen=v
}
chosen
}
 def genDaily(results,evoke){
"""
	<h1>Approaching God亲近神</h1>      
<p>	Think of the privilege of Prayer. Realize God is Present. Ask Him to help you pray.</p>
<p>思想我们祷告的权柄。意识到神就在这儿。请他帮助祷告。</p>
      ${evoke}
	<h1>Meditate His Word诵读默思他的话语</h1>      
      ${results}
<br/>
<p>Discern one or two truths you learn from these passages. Choose the one that most impresses you and write it in a sentence. </p><p>Now ask: How does this truth help me praise God? How does it show me a sin to confess? How does it show me something to ask God for? </p>	
<p>从这段经文中找出一两个真理。选择其中一个并写成句。问这些问题：这个真理如何帮助我赞美神？他如何揭示我当承认的罪？他如何显明我哪些方面需要求神帮助。</p>
<br/>
	<h1>Word Prayer话语祷告</h1>      
	<p>Turn the answers to the three questions into prayer-adoration, petition, and supplication</p>
	<p>将对这三个问题的答案转为祷告：颂赞，请求和祷告</p>
	<h1>Free Prayer自由祷告</h1>      
<p> Pray about whatever needs are on your heart. Spend time thanking God for the ways you see him working in your life and caring for you.  </p>
<p>将内心的负担向神祷告。感谢神在你生命中的工作和他对你的关爱。 </p>
<h1>Contemplation沉思</h1>
<p> Take a moment to thank and admire God for what he has showed you today. End with a note of praise. </p>
<p>感谢神的带领并赞美他。 </p>
"""
  }
  def getThreeyearSchedule() {
List threeschedule=new ArrayList()
  final threeplan=new File("threeyeardaily.txt")
	  threeplan.eachLine {line ->
    		threeschedule.add(line) }

    		threeschedule
  }
  def getthreeyearschedule(){
		def idx=index4today(2011,12,31,1095)
		def vs="gen 1"
  		vs=getThreeyearSchedule().get(idx) 
		vs
	}
	def index4today(year,mon,day,leng){
	  GregorianCalendar start= new GregorianCalendar(year,mon,day);
  GregorianCalendar end= new GregorianCalendar();
  long ms1 = start.getTime().getTime();
  long ms2 = end.getTime().getTime();
  long difMs = ms2-ms1;
  long msPerDay = 1000*60*60*24;
  ((int)(difMs / msPerDay)).mod(leng);
	}
def todaystring(){
        Date dateNow = new Date ();
       SimpleDateFormat dateformatMMDDYYYY = new SimpleDateFormat("MM-dd-yyyy");
	dateformatMMDDYYYY.format( dateNow ) 
}
def evokeverse=selectEvoke()
def head=new File("Head.txt").text
def end=new File("endhtml.txt").text
def todaytitle=todaystring()

def from="mailman@ccim.org"
def now=Calendar.getInstance().time
def format=new SimpleDateFormat("MMM-dd-yyyy")
def nw=format.format(now)

def subject="One Year Through Bible (UTF8)-${nw}" 
def content=dailytxt("ChiUn") 
def evoke= readStyledText("ChiUn", evokeverse, 0, 20)
 content=genDaily(content,evoke)
	content=head+content+end
def to="yhu@goantiques.com"

def vers=getthreeyearschedule()
head=new File("Head3yr.txt").text
subject="Three Year Read/Pray Through Bible-ChiNCVt ${todaytitle}"
 content=  readStyledText("ChiUn", vers, 0, 500)

println("orignal:"+content)
evoke= readStyledText("ChiUn", evokeverse, 0, 20)
 content=genDaily(content,evoke)
	content=head+content+end
to="three-year-pray-through-bible-traditional-chinese@googlegroups.com"
to="@yahoo.com"
  sendMail(from,to, subject, content,"UTF8")

println("verse:"+vers)

