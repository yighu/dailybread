import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.mail.*;
import javax.activation.*;
import javax.mail.internet.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

  def public  sendMail(from, to, subject, content,encoding)
  {
     Properties props = new Properties();
     props.put("mail.host", "rock.ccim.org");
     Session session = Session.getDefaultInstance(props, null);
     Message msg = new MimeMessage(session);
     msg.setFrom(new InternetAddress( from ));
     InternetAddress[] addressTo = new InternetAddress[1];
     addressTo[0] = new InternetAddress( to );
     msg.setRecipients(Message.RecipientType.TO, addressTo);
     msg.setHeader("Content-Encoding",encoding);
     msg.setSubject(subject);
     BodyPart messagebody=new MimeBodyPart();
	
     messagebody.setContent(content, "text/html;charset=utf-8");
     Multipart multipart=new MimeMultipart();
	multipart.addBodyPart(messagebody);
	msg.setContent(multipart);
     try
     {
        Transport.send(msg);
     }
     catch (e)
     {
         e.printStackTrace()
     }
  }
  def public  sendBig5Mail(from, to, subject, content)
  {
     // init sesssion
     Properties props = new Properties();
     props.put("mail.host", "rock.ccim.org");

     Session session = Session.getDefaultInstance(props, null);

     // create a message
     Message msg = new MimeMessage(session);

     // set addresses
     msg.setFrom(new InternetAddress( from ));

     InternetAddress[] addressTo = new InternetAddress[1];
     addressTo[0] = new InternetAddress( to );
     msg.setRecipients(Message.RecipientType.TO, addressTo);
     msg.setContentLanguage(("big5"));
     msg.setHeader("Content-Encoding","big5");
     msg.setSubject(subject);
     msg.setContent(content, "text/plain");

     try
     {
        Transport.send(msg);
     }
     catch (e)
     {
         e.printStackTrace()
     }
  }
  def public  sendMail(from, to, subject, content)
  {
     // init sesssion
     Properties props = new Properties();
     props.put("mail.host", "rock.ccim.org");

     Session session = Session.getDefaultInstance(props, null);

     // create a message
     Message msg = new MimeMessage(session);

     // set addresses
     msg.setFrom(new InternetAddress( from ));

     InternetAddress[] addressTo = new InternetAddress[1];
     addressTo[0] = new InternetAddress( to );
     msg.setRecipients(Message.RecipientType.TO, addressTo);

     // set the subject and content
     msg.setSubject(subject);
     msg.setContent(content, "text/plain");

     try
     {
        Transport.send(msg);
        //log.info("mail sent..")
     }
     catch (e)
     {
         e.printStackTrace()
         //log.warn("failed to send error mail: " + e)
     }
  }
  def public  sendMailwAttachment(from, to, subject, content,attachedfile)
  {
     // init sesssion
     Properties props = new Properties();
     props.put("mail.host", "rock.ccim.org");

     Session session = Session.getDefaultInstance(props, null);

     // create a message
     Message msg = new MimeMessage(session);

     // set addresses
     msg.setFrom(new InternetAddress( from ));

     InternetAddress[] addressTo = new InternetAddress[1];
     addressTo[0] = new InternetAddress( to );
     msg.setRecipients(Message.RecipientType.TO, addressTo);

     // set the subject and content
     msg.setSubject(subject);

// Create the message part
       BodyPart messageBodyPart = new MimeBodyPart();

// Fill the message
       messageBodyPart.setText(content);

       Multipart multipart = new MimeMultipart();
       multipart.addBodyPart(messageBodyPart);

// Part two is attachment
       messageBodyPart = new MimeBodyPart();
       String filename = attachedfile;
       DataSource source = new FileDataSource(filename);
       messageBodyPart.setDataHandler(new DataHandler(source));
       messageBodyPart.setFileName(filename);
       multipart.addBodyPart(messageBodyPart);

 msg.setContent(multipart);
     try
     {
        Transport.send(msg);
        //log.info("mail sent..")
     }
     catch (e)
     {
         e.printStackTrace()
         //log.warn("failed to send error mail: " + e)
     }
  }

def public  sendMailToMultiwAttach(from, recipients, subject, content, attachedfile) {
  // init sesssion
  Properties props = new Properties();
  props.put("mail.host", "rock.ccim.org");
  Session session = Session.getDefaultInstance(props, null);

  // create a message
  Message msg = new MimeMessage(session);

  // set addresses From
  msg.setFrom(new InternetAddress( from ));

  // set recipients
  InternetAddress[] addressTo = new InternetAddress[recipients.length];
  int count =0;
  recipients.each{
   addressTo[count++] = new InternetAddress( it );
  }
  msg.setRecipients(Message.RecipientType.TO, addressTo);

  // set the subject and content
  msg.setSubject(subject);

  // Create the message part
  BodyPart messageBodyPart = new MimeBodyPart();

  // Fill the message
  messageBodyPart.setText(content);

  Multipart multipart = new MimeMultipart();
  multipart.addBodyPart(messageBodyPart);

  // Part two is attachment
  messageBodyPart = new MimeBodyPart();
  String filename = attachedfile;
  DataSource source = new FileDataSource(filename);
  messageBodyPart.setDataHandler(new DataHandler(source));
  messageBodyPart.setFileName(filename);
  multipart.addBodyPart(messageBodyPart);

  msg.setContent(multipart);

  try{
     Transport.send(msg);
  } catch (e) {
      e.printStackTrace()
  }
}

  def public  sendMultiMail(from, to, subject, content)
  {
     // init sesssion
     Properties props = new Properties();
     props.put("mail.host", "rock.ccim.org");

     Session session = Session.getDefaultInstance(props, null);

     // create a message
     Message msg = new MimeMessage(session);

     // set addresses
     msg.setFrom(new InternetAddress( from ));

     InternetAddress[] addressTo = new InternetAddress[to.length];
     int count =0;
     to.each{
      addressTo[count++] = new InternetAddress( it );
     }
     msg.setRecipients(Message.RecipientType.TO, addressTo);
     // set the subject and content
     msg.setSubject(subject);
     msg.setContent(content, "text/plain");

     try
     {
        Transport.send(msg);
        //log.info("mail sent..")
     }
     catch (e)
     {
         e.printStackTrace()
         //log.warn("failed to send error mail: " + e)
     }
  }


def host = 'http://localhost:8080'
try {
  def results = new URL(host).getText()
 //sendMail("watchdog@ccim.org","@gmail.com", "localhost:8080 is up", "Yhc localhost:8080 is up","UTF8")
 new File("/home/tomcat/tomcat/bin/stacktrace.log").write("");
} catch (Exception e) {
 sendMail("watchdog@ccim.org","@gmail.com", "localhost:8080 is down", "Yes localhost:8080 is down:"+e.toString(),"UTF8")
}
